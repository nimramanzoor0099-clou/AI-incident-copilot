import { createApp } from './app.js'
import { config } from './config/index.js'
import { bootstrapDatabase } from './db/bootstrap.js'
import { closeDb } from './db/index.js'
import { getRetentionDays } from './db/repos/org.js'
import { purgeAnalysesOlderThan } from './db/repos/analyses.js'

bootstrapDatabase({ file: config.dbPath, seedDemo: config.seedDemoData, owner: config.owner })
const purged = purgeAnalysesOlderThan(getRetentionDays())
console.log(`Database ready: ${config.dbPath}${purged ? ` (removed ${purged} expired analyses)` : ''}`)

const server = createApp().listen(config.port, () => {
  console.log(`Incident Copilot API listening on http://localhost:${config.port}`)
})

const stop = () => server.close(() => { closeDb(); process.exit(0) })
process.on('SIGINT', stop)
process.on('SIGTERM', stop)
