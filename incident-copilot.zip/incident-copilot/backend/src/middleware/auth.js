import { config } from '../config/index.js'

// Optional shared-secret check. Disabled when API_KEY is empty.
export function apiKeyAuth(req, res, next) {
  if (!config.apiKey) return next()
  if (req.get('x-api-key') === config.apiKey) return next()
  res.status(401).json({ error: 'Missing or invalid x-api-key header' })
}
