import { getDb } from '../index.js'
import { ORG_ID } from '../constants.js'

export const listServiceNames = () => getDb().prepare('SELECT name FROM services WHERE org_id = ? ORDER BY id').all(ORG_ID).map((r) => r.name)

export function ensureService(name) {
  const db = getDb()
  db.prepare('INSERT INTO services (org_id, name, created_at) VALUES (?, ?, ?) ON CONFLICT (org_id, name) DO NOTHING').run(ORG_ID, name, Date.now())
  return db.prepare('SELECT id FROM services WHERE org_id = ? AND name = ?').get(ORG_ID, name).id
}
