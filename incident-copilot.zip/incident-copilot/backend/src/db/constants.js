// The API currently serves a single workspace. The schema is multi-workspace ready via org_id.
export const ORG_ID = 1
