import { StoreProvider } from './store'
import { useRoute } from './router'
import Shell from './components/Shell'
import Dashboard from './pages/Dashboard'
import IncidentsPage from './pages/IncidentsPage'
import IncidentPage from './pages/IncidentPage'
import CopilotPage from './pages/CopilotPage'
import SettingsPage from './pages/SettingsPage'

function Routes({ path }) {
  if (path.startsWith('/incidents/')) return <IncidentPage key={path} id={decodeURIComponent(path.split('/')[2])} />
  if (path === '/incidents') return <IncidentsPage />
  if (path === '/copilot') return <CopilotPage />
  if (path === '/settings') return <SettingsPage />
  return <Dashboard />
}

export default function App() {
  const path = useRoute()
  return (
    <StoreProvider>
      <Shell path={path}><Routes path={path} /></Shell>
    </StoreProvider>
  )
}
